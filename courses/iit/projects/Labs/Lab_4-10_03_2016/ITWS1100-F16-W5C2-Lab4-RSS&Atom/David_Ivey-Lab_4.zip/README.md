This was a huge pain to figure out what to do. I started so lost.
I eventually got a better understanding of what I was doing from 
looking at other feeds. From there everything was pretty straight
forward. The only other issue I found was not all feeds were
formatted the same way, so finding consistant information was 
difficult.

======================================================================

Resources & Collaborators:
Professor Plotka and his templates (God bless this man)
W3C validator (this, much this)
W3Schools for most things syntax
various RSS and Atom feeds for structure

======================================================================

Go to the following URL and click the Blogs link. The files I modified
have my name in the link name.

https://afsws.rpi.edu/AFS/home/16/iveyd/public_html/iit/index.html