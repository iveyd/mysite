For this lab, I wanted to mimic my current resume as closely as possible.
It took me a little while to figure out how I was going to float the bar
on the right side and get it to line up where I wanted, but I found that
if I put the information in a "Block" with a fixed size (relative to
the font) that everything lined up fairly well. My other issue was getting
the styling to behave how I wanted it to. I kept getting whole paragraphs
bolded when I only wanted a word or two bold. after playing around a bit I
figured it out to where I was happy. The last thing I wanted to do was to
make sure that you could view the page in the proper ratio. I worked on
the page as a half window next to my text editor, so when I looked at it in
full screen, it looked a bit off. I played with margins for a while until I
figured out that if you give the content a fixed container and set the left
and right margins to auto then it will center the content on the page for you.
overall, I mostly solved my problems by messing around with things until they
worked.

Resources & Collaborators:

Professor Plotka, W3Schools, css-tricks.com, html.com, validator.w3.org
