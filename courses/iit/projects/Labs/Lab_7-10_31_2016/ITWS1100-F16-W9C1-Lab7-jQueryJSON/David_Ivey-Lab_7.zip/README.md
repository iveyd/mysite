This lab was fairly straight forward. I used jquery to make
an ajax call to get the information from the json file and used that to populate the html page. I provided a test file (index.html)  with this submission so that you could see it work with out having to  go to my site, but I also integrated the javascript in with my  website
so that you could see it in production there if you wanted. 

Resources:
Professor Plotka's provided files, jquery.com
