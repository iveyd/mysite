For this lab, The only big issue I faced was the "placeholder" for 
the Text Area. Once I tought about what the mechanics should be, 
it was pretty straight forward though. I used onfocus instead of 
onclick for the comments section because I found that when I 
tabbed into the field, my function was not being run (because 
there was not clicking involved). 

Crimes: 
"Form labels that aren’t associated to form input fields" - I added "for" to the labels to connect them to their associated 
input

"Not indicating an active form field" - In the CSS I added a background color using the focus selector

Resources:
Professor Plotka and his provided files, W3C, Stack overflow for 
random errors (mostly just stupid mistakes I couldn't identify but 
found from seeing similar issues). 