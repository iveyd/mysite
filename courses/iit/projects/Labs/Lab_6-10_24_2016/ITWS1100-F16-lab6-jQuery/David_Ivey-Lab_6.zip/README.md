For this lab, the main issue I had was trying to access elements without Jquery.
for example, i was trying to call this.blah and could not figure out why it was
not working and then I tried $(this).blah and it worked fine. I believe this was
because using this did not actually tell the browser whqt element I was talking
about. Not positive on that though.

Resources:

Plotka, Jquery API docs, stack overflow.