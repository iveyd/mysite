The required part of the lab was mostly straight forward. 
I did both parts asynchronously so that I could test the operations. For the creativity portion, I decided to make a calculator. It did not end up being like a conventional calculator, but I thought it came out decently. 

Resources:
professor plotka's provided files. Stack overflow for syntax.
jquery documentation.