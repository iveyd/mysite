For this Lab, I tried to keep the html file as untouched as 
possible. The only thing that I changed was adding divs for 
each song, copy and pasting the div to account for each song, 
and changing the id to class for each attribute to account 
for having multiple songs. This is why the output for this 
lab looks different from the output from lab 2. the only 
difference should be the order of the image and the link to 
the album information is in the image rather than the album 
name text. 

Additionally, I wasn't sure output was wanted from lab 2, so
based on the HTML document structure, I assumed it was part 4.

this lab was fairly strightforward. Working with ajax and 
jquery makes life much easier for this kind of stuff (
although the syntax takes a little getting used to).

Resources:

W3C, Professor Plotka, stackoverflow for giving ajax and 
jquery examples so I could get a better understanding of how 
the functions worked.

