for this lab, I struggled a lot with figuring out how to work with the dom.
onve I understood how the dom worked and what the functions outputted, part 1
was fairly straight forward. For Part2, I honestly have no idea what was going
on, because I started off with exactly what is in the on load event handler
now, but for whatever reason it did not work at first. I had to try bunch of
other things that also didnt work until I finally went back to what I had and 
somehow it just started to work. needless to say I was pretty upset with the 
half-hour I wasted. For part 3 I spent another half-hour figuring out why it 
seemed like everything should be correct and yet it was not working until I 
realized that I needed to use "this" rather than getting the element again.


Reasources:

Professor Plotka, W3C, Stackoverflow (I am not sure exactly what, but I looked
through several threads to find explainations to problems I was facing).